// import { ComponentFixture, TestBed } from '@angular/core/testing';
// import { HttpClientModule } from '@angular/common/http';
// import { EditComponent } from './edit.component';
// import { ActivatedRoute, Router } from '@angular/router';
// import { of } from 'rxjs';
// import { NO_ERRORS_SCHEMA } from '@angular/compiler';

// describe('EditComponent', () => {
//   let component: EditComponent;
//   let fixture: ComponentFixture<EditComponent>;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpClientModule],
//       declarations: [EditComponent],
//     });
//     fixture = TestBed.createComponent(EditComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   fit('EditComponent_should_create', () => {
//     expect(component).toBeTruthy();
//   });
// });
